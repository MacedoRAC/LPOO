package Tests;

import static org.junit.Assert.*;

import org.junit.Test;

public class test{

/**
 * Tests if player avatar moves to the right place on
 * the board, according to the dice's values 
*/
@Test
public void playerMovesToRightPlace(){
    
}

/**
 * Tests if player after buying a new propertie has less money and
 * one more propertie on is collection
 */
@Test
public void playerBuyPropertie(){
    
}

/**
 * Tests if player after selling a new propertie has more money and
 * less one propertie on is collection
 */ 
@Test
public void playerSellProperty(){
    
}


/**
 * Verify the number of cards of each player
 * after the trade 
 */
@Test
public void playersTradeProperty(){
    
}

/**
 * Verify if a player is arrested when stop at "go to jail" 
 */
@Test
public void goToJail(){
    
}

/**
 * Verify if is added 200k to player when he pass start
 */
@Test
public void passByStart(){
    
}

/**
 * verify if the player won the game
 */
@Test
public void playerWon(){
    
}

/**
 * verify if the player lost the game
 */
@Test
public void playerLost(){
    
}

};
